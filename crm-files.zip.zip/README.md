# 🌟 CRM - Клиентлар Базаси

Замонавий веб-приложение оптовик клиентларни бошқариш учун.

## ✨ Имкониятлар

- 📊 **Dashboard** - Умумий статистика ва ҳисоботлар
- 👥 **Клиентлар** - Тўлиқ клиентлар базаси
- 📦 **Заказлар** - Заказлар тарихи ва бошқариш
- 📈 **Аналитика** - Савдо ҳисоботлари
- 🔐 **Хавфсизлик** - Firebase Authentication
- ☁️ **Облак** - Автоматик синхронизация
- 📱 **Responsive** - Барча қурилмаларда ишлайди

## 🚀 Ишга тушириш

### 1. Firebase созлаш

`FIREBASE_SETUP.md` файлини очиб детальный қўлланмани кўринг.

Қисқача:
1. Firebase Console да лойиҳа яратинг
2. Authentication ни ёқинг (Email/Password)
3. Firestore Database яратинг
4. Firebase конфигурацияни олинг

### 2. Конфигурация

`js/firebase-config.js` файлини очинг ва ўз конфигурациянгизни киритинг:

```javascript
const firebaseConfig = {
    apiKey: "sizning-api-key",
    authDomain: "sizning-project.firebaseapp.com",
    projectId: "sizning-project-id",
    // ...
};
```

### 3. Биринчи фойдаланувчи яратиш

Firebase Console -> Authentication -> Users -> Add user

Биринчи фойдаланувчини қўлда яратинг (email + password).

Кейин Firestore -> users коллекциясига қуйидагини қўшинг:

```json
{
  "email": "admin@example.com",
  "name": "Админ",
  "role": "owner",
  "createdAt": "текущая дата",
  "active": true
}
```

Document ID сифатида Authentication UID дан фойдаланинг!

### 4. Локал синаш

Файлларни браузерда очинг:
```
file:///c:/Users/User/.gemini/antigravity/playground/exo-radiation/index.html
```

Ёки Live Server ишлатинг (VS Code extension).

### 5. Онлайн қилиш

```bash
# Firebase CLI ўрнатинг
npm install -g firebase-tools

# Логин қилинг
firebase login

# Инициализация
firebase init

# Деплой
firebase deploy
```

Детальроқ: `FIREBASE_SETUP.md`

## 📂 Структура

```
├── index.html              # Асосий HTML
├── styles.css              # Дизайн
├── js/
│   ├── firebase-config.js  # Firebase созламалар
│   ├── auth.js             # Авторизация
│   ├── firebase-db.js      # Маълумотлар базаси
│   ├── utils.js            # Ёрдамчи функциялар
│   └── app.js              # Асосий логика
├── firebase.json           # Firebase хостинг
├── .gitignore
├── FIREBASE_SETUP.md       # Детальный гайд
└── README.md               # Бу файл
```

## 🔐 Роллар

1. **Директор (owner)** - Тўлиқ назорат
2. **Бош менежер (admin)** - Бошқариш
3. **Савдо менежери (manager)** - Савдо
4. **Оператор (operator)** - Заказлар
5. **Кузатувчи (viewer)** - Фақат кўриш

## 🛠 Технологиялар

- HTML5 + CSS3 + JavaScript (ES6+)
- Firebase (Auth + Firestore + Hosting)
- Responsive Design
- Modern UI/UX

## 📱 Қўллаб-қувватлаш

- ✅ Chrome, Firefox, Safari, Edge
- ✅ Desktop (Windows, Mac, Linux)
- ✅ Mobile (iOS, Android)
- ✅ Tablet

## 📞 Ёрдам

Саволлар бўлса, `FIREBASE_SETUP.md` қўлланмасини кўринг.

---

**Муваффақият тилайман! 🚀**
